﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Encryption
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {

           
         var txt_sqls= txt_sql.Text.Trim();
            var db = txt_db.Text.Trim();
            var uid = txt_userid.Text.Trim();
            var pwd = txt_pwd.Text.Trim();
                if(!string.IsNullOrEmpty(txt_sqls)&&!string.IsNullOrEmpty(db)&&!string.IsNullOrEmpty(uid)&&!string.IsNullOrEmpty(pwd))
                {
                    var constring = "Data Source =" + txt_sqls + "; Initial Catalog = " + db + "; Integrated Security = false; User ID = " + uid + "; Password = " + pwd + "";
                   
                    var key = "o14ca5898c4e4133bbce2sg2315a2024";
                    var encrtypted_text = EncryptString(key, constring);
                    txt_con.Text = encrtypted_text;
                }
                else
                {
                    MessageBox.Show("Please fill all the Text Data");
                }
          
            }
            catch (Exception eve)
            {
                MessageBox.Show(eve.Message);
            }

        }

        public static string EncryptString(string key, string plainText)
        {
            byte[] iv = new byte[16];
            byte[] array;

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = iv;

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                        {
                            streamWriter.Write(plainText);
                        }

                        array = memoryStream.ToArray();
                    }
                }
            }

            return Convert.ToBase64String(array);
        }
        public static string DecryptString(string key, string cipherText)
        {
            byte[] iv = new byte[16];
            byte[] buffer = Convert.FromBase64String(cipherText);

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = iv;
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream memoryStream = new MemoryStream(buffer))
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                        {
                            return streamReader.ReadToEnd();
                        }
                    }
                }
            }
        }
    }
}
